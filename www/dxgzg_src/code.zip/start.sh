cd /test
./Pine