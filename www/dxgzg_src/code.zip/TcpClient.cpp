#include "TcpClient.h"
#include "EventLoop.h"
#include "Logger.h"
#include "Buffer.h"

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>

using namespace std;

TcpClient::TcpClient(EventLoop* loop,int clientFd)
            :clientFd_(new Socket(clientFd)),channel_(std::make_unique<Channel>(loop,clientFd)),
            loop_(loop),
            inputBuffer_(make_unique<Buffer>())
{
    channel_->setReadCallback(std::bind(&TcpClient::ReadCallback,this));// 这是默认的，客户端也可以再次调用
    channel_->setCloseCallback(std::bind(&TcpClient::CloseCallback,this));
    channel_->setWriteCallback(std::bind(&TcpClient::sendExtra,this));
    readCallback_ = nullptr;
}
TcpClient::~TcpClient(){
    LOG_INFO("客户端退出连接");
}

void TcpClient::registerClient(){
    // 线程安全注册回调函数
    channel_->enableReadEvent();
}

void TcpClient::CloseCallback(){
    channel_->setIndex(2);// 准备删除操作。
    channel_->disableReadEvent();
    auto ptr = shared_from_this();
    closeCallback_(ptr);
}
void TcpClient::ReadCallback(){
    if(readCallback_){// 如果有就调用用户自定义的回调，没有的话，用这个; 
        int n = inputBuffer_->recvMsg(clientFd_->getFd());
        if(n <= 0){
            if(n == -1){
                LOG_ERROR("recv error");
            }
            CloseCallback();
            return ;
        }
        readCallback_(shared_from_this(),inputBuffer_.get());
        return ;
    }
    else{ // 默认的
    //     int fd = clientFd_->getFd();
    //     char buff[1024];
    //     //int r =1;
    //     int r = ::recv(fd,buff,sizeof(buff),0);
    //     if(r == 0){ // 处理关闭
    //         // 重新设置下状态，然后关闭
    //         CloseCallback();
    //         closeCallback_(shared_from_this());
    //         return ;
    //     }
    //     buff[r] = '\0';
    // //  LOG_INFO("收到一条消息:%s",buff);
    //     send(fd,buff,strlen(buff),0);
    }
}



int TcpClient::send(std::string msg){
    size_t n = outputBuffer_->send(clientFd_->getFd(),msg);
    if(n == UINT64_MAX){
        CloseCallback();
    }
    if(msg.size() > n){
        channel_->enableWriteEvent();
    }
    return n;
}

void TcpClient::sendExtra(){
    // channel可写事件的回调函数。
    string s = outputBuffer_->getAllString();
    size_t n = outputBuffer_->send(clientFd_->getFd(),s);
    if(n == s.size()){
        channel_->disableWriteEvent();
    }
    if(n == UINT64_MAX){
        CloseCallback();
    }
}