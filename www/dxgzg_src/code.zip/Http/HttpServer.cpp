#include "HttpServer.h"
#include "TcpClient.h"
#include "Logger.h"
#include "Buffer.h"


using namespace std;

void HttpServer::ReadCallback(Pine::clientPtr t,Buffer* inputBuffer){
    LOG_INFO("%s:%d<%s>",__FILE__,__LINE__,__FUNCTION__);
    string str = inputBuffer->getAllString();
    LOG_INFO("%s",str.c_str());
    httpRequest_.request(t.get(),str);
}

void HttpServer::run(){
    tcpServer_.setThreadNum(4);
    tcpServer_.setClientReadCallback(std::bind(&HttpServer::ReadCallback,this,std::placeholders::_1,std::placeholders::_2));
    tcpServer_.start();
    loop_.loop();
}